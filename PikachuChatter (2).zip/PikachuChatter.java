public class PikachuChatter {
//This program creates Pikachu characters.
   public static void main (String[] args) {
   PikachuChatter1();
   PikachuChatter2();
   }
   
   public static void PikachuChatter1() {
   System.out.println("Pika pika pika chu pika chu peeeee ka pika chu!");
   System.out.println("(\\__/)");
   System.out.println("(o^.^)");
   System.out.println("z(_(\")(\")");
   }
   
   public static void PikachuChatter2() {
   System.out.println("Pika? Pika pika pika chu peeeee ka chu!");
   System.out.println("(\\__/)");
   System.out.println("(o^.^)");
   System.out.println("z(_(\")(\")");
   }
}