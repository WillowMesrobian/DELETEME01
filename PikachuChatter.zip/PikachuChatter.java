public class PikachuChatter {
   public static void main (String[] args) {
   System.out.println("Pika pika pika chu pika chu peeeee ka pika chu!");
   System.out.println("(\\__/)");
   System.out.println("(o^.^)");
   System.out.println("z(_(\")(\")");
   System.out.println();
   System.out.println("Pika pika pika chu pika chu peeeee ka pika chu!");
   System.out.println("(\\__/)");
   System.out.println("(o^.^)");
   System.out.println("z(_(\")(\")");
   }
}